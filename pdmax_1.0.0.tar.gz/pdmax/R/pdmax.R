#' pdmax 1.0.0: market forecast for Amazonas Energia AmE
#' @param arquivo path/xlsx_filename of the AmE demand data (character) example Demanda maxima verificado 2018 a 2026 (3).xlsx
#' @param arquivopib path/xlsx_filename of the historical series and GDP forecasts for Amazonas (character)
#' @param arquivoindice path/csv_filename with Amazonas economic activity index (character)
#' @param arquivomarketmodel path/csv_filename of the AmE market data (historical and forecast)         
#' @param nivel_tensao select a voltage level, e.g., "069" (69 kV) or "138" (138 kV)
#' @param lista_barras Select one or more busbars, e.g., c("CENTRO-AM138","CH.GRA-AM138","COMPEN-AM138")
#' @param ano_mes_inic date (year,month) corresponding for the beginning of the series analyzed (numeric) example c(2017,1)
#' @param ano_mes_fim date (year,month) corresponding for the end of the series analyzed (numeric) example c(2025,6)
#' @param horizonte forecast horizon in months (numeric) example 12
#' @param variavel_prevista select of one to four options from the following variables: "leve", "media", "pesada", and "coincidente".
#' @param tipo Select one of the five demand forecasting models (1, 2, 3, 4 or 5).
#' @param grafico logical variable: true to display graph and false to not display (logical)
#' @return list containing monthly and annual forecasts of the system's maximum demand and of each busbar's maximum demand by load level.
#'
#' @author
#' José Pessanha \email{pessanha@ime.uerj.br}
#'
#' Albert Melo \email{albert.melo@ime.uerj.br}
#'
#' Maria Elvira \email{melvira@ime.uerj.br}
#'
#' @references
#' Hyndman, R.J, & Athanasopoulos, G. (2021). *Forecasting: Principles and Practice*,3rd edition, OTexts.
#'  Disponível em: \url{https://otexts.com/fpp3/}
#'
#' Makridakis, S, Spiliotis,E., Assimakopoulos, V. (2018). *Statistical and machine learning forecasting methods: Concerns and ways forward*. Plos One, 13(3): e0194889. https://doi.org/ 10.1371/journal.pone.0194889.
#'
#' @examples
#' \dontrun{
#' # Example of usage with hypothetical files
#' result <- marketmodel(
#'   arquivo       = "data/demanda_Amazonas.xlsx",
#'   arquivopib    = "data/pib_Amazonas.xlsx",
#'   arquivoindice = "data/indice_atividade.csv",
#'   arquivomarketmodel = "data/mercado_Amazonas.csv",
#'   nivel_tensao = "138"
#'   lista_barras = c("CENTRO-AM138","CH.GRA-AM138","COMPEN-AM138")
#'   ano_mes_inic  = c(2017,1),
#'   ano_mes_fim  = c(2026,3),
#'   horizonte     = 120,
#'   variavel_prevista = c("leve","media","pesada")
#'   tipo = 1
#'   grafico = TRUE,
#' )
#'
#' # Access monthly forecasts
#' result$previsoes
#'
#' # Access annual forecasts
#' result$previsoes_anuais
#'
#' # Access the busbar time series
#' result$series_barras
#'
#' # Access the system's maximum demand time series.
#' result$series_sistema
#' 
#' # Access performance metrics.
#' result$metricas
#'
#' }
#'
#' @export

pdmax<-function(arquivo,arquivopib,arquivoindice,arquivomarketmodel,nivel_tensao,lista_barras,ano_mes_inic,ano_mes_fim,horizonte,variavel_prevista,tipo,grafico=FALSE){
  # PREVISOR DE DEMANDA MAXIMA POR BARRAMENTO DO SISTEMA INTERLIGADO DA AME
  diretorio=dirname(arquivo)
  saida_metricas_modelos=c()
  for (imodelo in 1:length(tipo)){
    tipomodelo=tipo[imodelo]
    saida_metricas=c()
    nome_variavel_prevista=c()
    
    for (i in 1:length(variavel_prevista)){
      momento=Sys.time()
      print(momento)
      print(paste("#### MODELO ",tipomodelo,"####"))
      aux=variavel_prevista[i]
      print(paste("#### EXECUTANDO PREVISAO DA VARIAVEL",aux,"####"))
      nome_arquivo_saida <- paste0(diretorio,"/",aux,"_modelo_",imodelo,"_",format(momento, "%Y%m%d_%H%M%S"), ".csv")
      resultado=prevdemanda(arquivo,arquivopib,arquivoindice,arquivomarketmodel,nivel_tensao,lista_barras,ano_mes_inic,ano_mes_fim,horizonte,aux,tipomodelo)
      print(paste("GRAVANDO ARQUIVO COM PREVISOES DA VARIAVEL",aux))
      print(nome_arquivo_saida)
      write.table(resultado$matriz_previsoes_barras,nome_arquivo_saida,sep=";",dec=",",row.names = FALSE)
      nome_arquivo_saida <- paste0(diretorio,"/",aux,"_modelo_",imodelo,"_ANUAL_",format(momento, "%Y%m%d_%H%M%S"), ".csv")
      maximos_anuais=resultado$matriz_previsoes_barras %>%
        index_by(ano = year(index)) %>%
        summarise(
          across(where(is.numeric), \(x) max(x, na.rm = TRUE))
        )
      write.table(maximos_anuais,nome_arquivo_saida,sep=";",dec=",",row.names = FALSE)
      
      # CALCULA ERROS PREVISOES BARRAS
      previsoes=resultado$matriz_previsoes_barras
      dados_brutos=resultado$series_barras
      for (ibarra in 1:length(lista_barras)){
        busbar=lista_barras[ibarra]
        metricas_barras=avalia_previsao_barra(dados_brutos,previsoes,busbar,aux,tipomodelo,grafico)
        temporario=data.frame(busbar,metricas_barras)
        colnames(temporario)[1]="barra"
        saida_metricas=rbind(saida_metricas,temporario)
        nome_variavel_prevista=c(nome_variavel_prevista,aux)
      }
      names(saida_metricas)[1]="barra"
      
      if (i==length(variavel_prevista)){
        # CALCULA ERROS PREVISOES SISTEMA
        # a demanda do sistema e a mesma para todas as variaveis, entao imprime so uma vez
        previsoes=resultado$matriz_previsoes_barras
        sistema_MW=resultado$serie_sistema
        metricas_sistema<-avalia_previsao_sistema(previsoes,sistema_MW,tipomodelo,grafico)
        saida_metricas_sistema=data.frame("sistema",metricas_sistema)
        nome_variavel_prevista=c(nome_variavel_prevista,"demanda maxima do sistema")
        names(saida_metricas_sistema)[1]="barra"
        saida_metricas=rbind(saida_metricas,saida_metricas_sistema)
      }
    }
    modelo=rep(tipomodelo,length(nome_variavel_prevista))  
    saida_metricas=cbind(saida_metricas,nome_variavel_prevista,modelo)
    saida_metricas_modelos=rbind(saida_metricas_modelos,saida_metricas)
  }
  nome_arquivo_saida <- paste0(diretorio,"/","DESEMPENHO_", format(momento, "%Y%m%d_%H%M%S"), ".csv")
  print("GRAVANDO ARQUIVO COM METRICAS DE DESEMPENHO")
  print(nome_arquivo_saida)
  write.table(saida_metricas_modelos,nome_arquivo_saida,sep=";",dec=",",row.names = FALSE)
  print("EXECUCAO FINALIZADA COM SUCESSO")
  
  if (length(tipo)==1 & length(variavel_prevista)==1){
    return(list(previsoes=resultado$matriz_previsoes_barras,previsoes_anuais=maximos_anuais,series_barras=resultado$series_barras,serie_sistema=resultado$serie_sistema,metricas=saida_metricas_modelos))
  } else {
    return(saida_metricas_modelos)
  }
}

prevdemanda<-function(arquivo,arquivopib,arquivoindice,arquivomarketmodel,nivel_tensao,lista_barras,ano_mes_inic,ano_mes_fim,horizonte,variavel_prevista,tipo){
# ROTINA PREVISAO DEMANDA MAXIMA POR BARRA #
# arquivo = planilha produzida pela AME com dados da demanda maxima
# arquivopib = arquivo com serie historica e previsao do pib do Amazonas
# arquivoindice = arquivo com serie historica da atividade economica do Amazonas
#                 https://dadosabertos.bcb.gov.br/dataset/25411-sgs
# arquivomarketmodel = arquivo com historico e previsao de mercado do marketmodel
# nivel_tensao = "138" ou "69" kv
# lista_barras = lista com nomes das barras a serem analisadas
# ano_mes_inic = inicio do periodo historico, c(2017,1)
# ano_mes_fim = fim do periodo historico, c(2024,12)
# horizonte = horizonte de previsao em meses, por exemplo, 12
# variavel_prevista = "leve","media","pesada" ou "coincidente")  
# tipo = tipo do modelo 1,2,3,4,5
library(openxlsx)
library(dplyr)
library(tibble)
library(dplyr)
library(tidyr)
library(zoo)
library(plm)
library(tsibble)
library(lubridate)
library(fpp3)
library(readxl)
library(tempdisagg)

# TIPOS DE MODELOS
if (tipo==1) {
    modelo_fator_de_carga = "media"
    modelo_fator_participacao = "media" 
}
if (tipo==2) {
    modelo_fator_de_carga = "previsao"
    modelo_fator_participacao = "previsao" 
}
if (tipo==3) {
    # demanda maxima do sistema prevista pelo pib
    modelo_fator_de_carga = "nao utilizado"
    modelo_fator_participacao = "media"
}
if (tipo==4) {
    # demanda maxima do sistema prevista pelo pib
    modelo_fator_de_carga = "nao utilizado"
    modelo_fator_participacao = "previsao"
}
if (tipo==5) {
    # demanda maxima da barra prevista a partir da propria serie historica
    modelo_fator_de_carga = "nao utilizado"
    modelo_fator_participacao = "nao utilizado"
}
  
print("#### MODELO DE PREVISAO DA DEMANDA MAXIMA POR BARRA ####")  
if (modelo_fator_de_carga=="media" | modelo_fator_de_carga=="previsao"){
   # apenas modelos tipo 1 e 2 entram aqui
   if (tipo==1) print("previsao da demanda maxima do sistema a partir da previsao de mercado e media do fator de carga")
   if (tipo==2) print("previsao da demanda maxima do sistema a partir das previsoes de mercado e fator de carga")
   print("previsao de demanda maxima = previsao de mercado / (horas x fator de carga)")
   #### LEITURA DO ARQUIVO COM HISTORICO E PREVISOES DE MERCADO 
   #### ENTRA AQUI SE PREVISAO DE DEMANDA MAXIMA = PREVISAO MERCADO / FATOR DE CARGA
   dados_mercado=read.csv2(file=arquivomarketmodel,sep=";",dec=",") 
   print("leitura do arquivo com historico e previsao de mercado")
   ano_inicio=as.numeric(substr(dados_mercado$mes,1,4))[1]
   mes_inicio <- match(sub(".* ", "",dados_mercado$mes[1]),c("jan", "fev", "mar", "abr", "mai", "jun","jul", "ago", "set", "out", "nov", "dez"))
   serie_mercado=dados_mercado[,2]
   serie_mercado=ts(serie_mercado,start=c(ano_inicio,mes_inicio),freq=12)
} else {
   # modelos tipo 3, 4 e 5 entram aqui
   if (tipo==3 | tipo==4) print("previsao da demanda maxima do sistema por regressao no PIB do Amazonas")
   if (tipo==5) print("previsao da demanda maxima do sistema por modelo de serie temporal")
}  

# tipo de previsao do fator de participacao
if (tipo == 1 | tipo == 3) print("previsao do fator de participacao dada pela media historica")  
if (tipo == 2 | tipo == 4) print("previsao do fator de participacao obtida por modelo de serie temporal")  
if (tipo == 5 ) print("previsao da demanda por barra por modelo de serie temporal")  

if (tipo == 3 | tipo == 4){
   # MONTA SERIE HISTORICA E PREVISAO DO PIB
   #### LEITURA DO ARQUIVO COM INDICE DE ATIVIDADE REGIONAL IBCR-AM ####
   print("leitura do arquivo com indice de atividade regional IBCR-AM")
   #log_msg(diretorio_log_execucao,"leitura do arquivo com indice de atividade regional IBCR-AM")
   dadosindice=read.csv2(file=arquivoindice,sep=";",dec=",") # indice mensal de atividade
   mes0=as.numeric(substr(dadosindice$Data,1,2)[1]) # mes inicial da serie do indice
   ano0=as.numeric(substr(dadosindice$Data,7,10)[1]) # ano inicial da serie do indice
   serie_mensal=ts(dadosindice$IBCR.AM,start=c(ano0,mes0),frequency=12)

   #### LEITURA DO ARQUIVO COM ESTIMATIVAS DO PIB ####
   print("leitura do arquivo do PIB do Amazonas")
   #log_msg(diretorio_log_execucao,"leitura do arquivo do PIB do Amazonas")
   dadosPIB=read_excel(path=arquivopib,sheet=1,skip=1) # pib
   serie_anual=ts(dadosPIB$PIB,start=dadosPIB$Ano[1],frequency=1)

   #### SAZONALIZACAO DO PIB ####
   print("sazonalizacao do PIB")
   inicio_anual_usuario <-  ano_mes_inic[1]
   fim_anual_usuario <-  ano_mes_fim[1]
   inicio_anual <- start(serie_anual)[1] # serie do PIB
   fim_anual    <- end(serie_anual)[1] # serie do PIB
   inicio_mes_usuario <-  ano_mes_inic[2]
   fim_mes_usuario <-  ano_mes_fim[2]
   inicio_mensal <- start(serie_mensal)[1] # serie do IBCR
   fim_mensal    <- end(serie_mensal)[1] # serie do IBCR
   inicio_comum <- max(inicio_anual_usuario,inicio_anual,inicio_mensal)
   fim_comum <- min(fim_anual_usuario,fim_anual)
   #  if (end(serie_mensal)[2] == 12) fim_mensal else fim_mensal - 1

   serie_anual_comum <- suppressWarnings(window(serie_anual,start = inicio_comum,end = fim_comum))
   serie_mensal_comum <- suppressWarnings(window(serie_mensal,start = c(inicio_comum, 1),end = c((fim_comum), 12)))
   fit <- td(serie_anual_comum ~ serie_mensal_comum,to = "monthly",method = "chow-lin-maxlog")
   pib_mensal=predict(fit) # SERIE HISTORICA DO PIB

   # calculo do perfil sazonal e previsao sazonalizada do PIB
   previsao_pib_anual <- suppressWarnings(window(serie_anual, start = (fim_comum+1)))
   pib_anual_hist <- aggregate(pib_mensal, nfrequency = 1, FUN = sum)
   totais_repetidos <- rep(as.numeric(pib_anual_hist), each = 12)
   perfil_mensal <- as.numeric(pib_mensal) / totais_repetidos
   perfil_matriz <- matrix(perfil_mensal,ncol = 12,byrow = TRUE)
   colnames(perfil_matriz) <- month.abb # nomes meses abreviados
   rownames(perfil_matriz) <- inicio_comum:(fim_comum)
   perfil_sazonal <- colMeans(perfil_matriz)
   # desagrega previsoes anuais do PIB em previsoes mensais
   pib_mensal_prev <- outer(as.numeric(previsao_pib_anual),perfil_sazonal)
   pib_previsao_ts <- ts(as.vector(t(pib_mensal_prev)),start = c((fim_comum+1), 1),frequency = 12)
   pib_previsao_tsibble <- pib_previsao_ts %>%as_tsibble() # PREVISAO DO PIB
}

#### LEITURA DE DADOS DE DEMANDA MAXIMA ####
print("leitura da demanda maxima")
abas <- getSheetNames(arquivo)
# serie de demanda do sistema #
x=read.xlsx(arquivo,sheet=1,startRow=3)
x[is.na(x)] <- -1
x_ano_inic=as.numeric(names(x)[2])
x_mes_inic=match(x[1,1],c("jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"))
# remover a coluna dos meses
mat <- as.matrix(x[,-1])
# transformar em vetor por colunas (jan-dez de 2017, depois jan-dez de 2018, ...)
seriex <- as.vector(mat)
# criar objeto ts
sistema_MW <- ts(seriex,start = c(x_ano_inic,x_mes_inic),frequency = 12)
sistema_MW[sistema_MW == -1]<-NA # serie de demanda maxima do sistema

previsao_demanda_sistema=0
if (modelo_fator_de_carga=="media" | modelo_fator_de_carga=="previsao"){
   # entra aqui se modelos tipo 1 e 2
   # MODELAGEM DO FATOR DE CARGA
   sistema_MW1=suppressWarnings(window(sistema_MW,start=c(ano_mes_inic[1],ano_mes_inic[2]),end=c(ano_mes_fim[1],ano_mes_fim[2])))
   serie_mercado1=suppressWarnings(window(serie_mercado,start=c(ano_mes_inic[1],ano_mes_inic[2]),end=c(ano_mes_fim[1],ano_mes_fim[2])))
   # Monta series com período comuns das series de mercado e demanda maxima
   df_sistema <- data.frame(data = time(sistema_MW1),demanda_maxima = as.numeric(sistema_MW1))
   df_mercado <- data.frame(data = time(serie_mercado1),mercado = as.numeric(serie_mercado1))
   # Interseção das datas
   dados_comuns <- merge(df_sistema,df_mercado,by = "data")
   dados_comuns <- dados_comuns[complete.cases(dados_comuns),]
   # Series no período comum
   demanda_maxima <- ts(dados_comuns$demanda_maxima,start=dados_comuns$data[1],freq=12)
   mercado <- ts(dados_comuns$mercado,start=dados_comuns$data[1],freq=12)
   novasdatas <- as.Date(paste0(floor(dados_comuns$data),"-",sprintf("%02d", round((dados_comuns$data - floor(dados_comuns$data)) * 12) + 1),"-01"))
   horas = as.integer(format(seq(as.Date(novasdatas)[1], by = "month", length.out = length(novasdatas) + 1)[-1] - 1,"%d")) * 24
   # serie do fator de carga
   fator_carga=(mercado/1000)/(horas*demanda_maxima)
   if (modelo_fator_de_carga == "previsao"){
       print("previsao do fator de carga por modelo ETS")
       fator_carga_tsibble <- as_tsibble(fator_carga)
       # previsao do fator de carga por Holt-Winters
       modelo_hw <- fator_carga_tsibble |> model(hw = ETS(value ~ error("A") + trend("A") + season("A", period = 12)))
       prev_fator_carga <- modelo_hw |>  forecast(h = horizonte)
       prev_fator_carga=prev_fator_carga$.mean
   } else {
       # fator de carga é a Média móvel dos últimos 5 anos para cada mês (mais robusto)
       print("previsao do fator de carga por media historica mensal")
       ultimos_5_anos=tail(fator_carga,60)
       medias_mensais <- tapply(ultimos_5_anos,cycle(ultimos_5_anos),mean,na.rm = TRUE)
       primeiro_periodo <- tail(time(fator_carga), 1) + 1/ frequency(fator_carga)
       ano <- floor(primeiro_periodo) # ano do primeiro mes do horizonte
       mes <- as.numeric(round((primeiro_periodo - ano) * 12) + 1) # primeiro mes do horizonte
       cont=mes
       previsoes=c()
       for (i in 1:horizonte){
            previsoes = c(previsoes,medias_mensais[cont])
            cont=cont+1
            if (cont>12) cont=1
       }
       prev_fator_carga=as.numeric(previsoes)
   }
   primeiro_periodo <- tail(time(sistema_MW1), 1) + 1/ frequency(sistema_MW1)
   ano <- floor(primeiro_periodo) # ano do primeiro mes do horizonte
   mes <- as.numeric(round((primeiro_periodo - ano) * 12) + 1) # primeiro mes do horizonte
   previsao_mercado=suppressWarnings(window(serie_mercado, start = c(ano,mes)))
   horas = as.integer(format(seq(as.Date(paste(ano,"-",mes,"-",01,sep="")), by = "month", length.out = horizonte + 1)[-1] - 1,"%d")) * 24
   previsao_demanda_sistema=previsao_mercado[1:min(horizonte,length(prev_fator_carga))]/(1000*horas*prev_fator_carga)
}

# consolida dados dos barramentos #
print("consolidando dados dos barramentos")
for (k in 2:length(abas)){
     #print(paste("leitura",abas[k]))
     dados=read.xlsx(arquivo,sheet=k,startRow=6)
     limite=which(dados$Nº=="TOTAL CARGA AGRUPAMENTO 1")
     indice=seq(1,(limite-1),1)
     ano=as.numeric(substr(abas[k],(nchar(abas[k])-3),nchar(abas[k])))
     GP=dados$`G/P`[indice]
     num_barramentos=dados$Nº[indice]
     nomes_barramentos=dados$NOME[indice]
     tensao=sub(".*AM","",nomes_barramentos)
     
     # pesada dia útil
     demanda_max=dados[indice,seq(5,28,2)]
     demanda_max[is.na(demanda_max)]<-0
     demanda_max=data.frame(lapply(demanda_max, function(x)
                                                         suppressWarnings(as.numeric(as.character(x))))
                                                )
     demanda_max=round(demanda_max,2)
     if (k==2) {
         DADOS_CONSOLIDADOS_PESADA=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
     }else{
         aux=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
         DADOS_CONSOLIDADOS_PESADA=rbind(DADOS_CONSOLIDADOS_PESADA,aux)   
     }
     
     # media dia útil
     demanda_max=dados[indice,seq(29,52,2)]
     demanda_max[is.na(demanda_max)]<-0
     demanda_max=data.frame(lapply(demanda_max, function(x)
       suppressWarnings(as.numeric(as.character(x))))
     )
     demanda_max=round(demanda_max,2)
     if (k==2) {
       DADOS_CONSOLIDADOS_MEDIA=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
     }else{
       aux=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
       DADOS_CONSOLIDADOS_MEDIA=rbind(DADOS_CONSOLIDADOS_MEDIA,aux)   
     }
     
     # leve dia útil
     demanda_max=dados[indice,seq(53,76,2)]
     demanda_max[is.na(demanda_max)]<-0
     demanda_max=data.frame(lapply(demanda_max, function(x)
       suppressWarnings(as.numeric(as.character(x))))
     )
     demanda_max=round(demanda_max,2)
     if (k==2) {
       DADOS_CONSOLIDADOS_LEVE=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
     }else{
       aux=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
       DADOS_CONSOLIDADOS_LEVE=rbind(DADOS_CONSOLIDADOS_LEVE,aux)   
     }

     # demanda maxima nao coincidente
     demanda_max=dados[indice,seq(197,220,2)]
     demanda_max[is.na(demanda_max)]<-0
     demanda_max=data.frame(lapply(demanda_max, function(x)
       suppressWarnings(as.numeric(as.character(x))))
     )
     demanda_max=round(demanda_max,2)
     if (k==2) {
       DADOS_CONSOLIDADOS_MAXCOIN=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
     }else{
       aux=data.frame(rep(ano,length(num_barramentos)),num_barramentos,nomes_barramentos,GP,tensao,demanda_max)
       DADOS_CONSOLIDADOS_MAXCOIN=rbind(DADOS_CONSOLIDADOS_MAXCOIN,aux)   
     }
}
names(DADOS_CONSOLIDADOS_PESADA)=c("ano","numero","barra","GP","tensao","jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez")
names(DADOS_CONSOLIDADOS_MEDIA)=c("ano","numero","barra","GP","tensao","jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez")
names(DADOS_CONSOLIDADOS_LEVE)=c("ano","numero","barra","GP","tensao","jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez")
names(DADOS_CONSOLIDADOS_MAXCOIN)=c("ano","numero","barra","GP","tensao","jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez")

# muda para tibble
DADOS_CONSOLIDADOS_PESADA_tibble=as_tibble(DADOS_CONSOLIDADOS_PESADA)
DADOS_CONSOLIDADOS_MEDIA_tibble=as_tibble(DADOS_CONSOLIDADOS_MEDIA)
DADOS_CONSOLIDADOS_LEVE_tibble=as_tibble(DADOS_CONSOLIDADOS_LEVE)
DADOS_CONSOLIDADOS_MAXCOIN_tibble=as_tibble(DADOS_CONSOLIDADOS_MAXCOIN)

# organiza dados por ano e barra
DADOS_CONSOLIDADOS_PESADA_tibble=DADOS_CONSOLIDADOS_PESADA_tibble %>%
  group_by(ano, barra) %>%
  summarise(
    tensao = first(tensao),
    across(jan:dez, ~sum(.x, na.rm = TRUE)),
    .groups = "drop"
  )
DADOS_CONSOLIDADOS_MEDIA_tibble=DADOS_CONSOLIDADOS_MEDIA_tibble %>%
  group_by(ano, barra) %>%
  summarise(
    tensao = first(tensao),
    across(jan:dez, ~sum(.x, na.rm = TRUE)),
    .groups = "drop"
  )
DADOS_CONSOLIDADOS_LEVE_tibble=DADOS_CONSOLIDADOS_LEVE_tibble %>%
  group_by(ano, barra) %>%
  summarise(
    tensao = first(tensao),
    across(jan:dez, ~sum(.x, na.rm = TRUE)),
    .groups = "drop"
  )
DADOS_CONSOLIDADOS_MAXCOIN_tibble=DADOS_CONSOLIDADOS_MAXCOIN_tibble %>%
  group_by(ano, barra) %>%
  summarise(
    tensao = first(tensao),
    across(jan:dez, ~sum(.x, na.rm = TRUE)),
    .groups = "drop"
  )

# monta series da demanda em cada barra
MONTA_SERIES<-function(X){
      series <- X%>%
                 pivot_longer(
                 cols = jan:dez,
                 names_to = "mes",
                 values_to = "demanda"
       )
       series <- series %>%
                  mutate(
                    mes_num = match(mes,
                      c("jan","fev","mar","abr","mai","jun",
                        "jul","ago","set","out","nov","dez")),
                      periodo = sprintf("%04d-%02d", ano, mes_num)
                  )
       serie_larga <- series %>%
                       select(barra, periodo, demanda) %>%
                       pivot_wider(
                       names_from = periodo,
                       values_from = demanda
       )
       return(serie_larga)
}
series_pesada=MONTA_SERIES(DADOS_CONSOLIDADOS_PESADA_tibble)
series_media=MONTA_SERIES(DADOS_CONSOLIDADOS_MEDIA_tibble)
series_leve=MONTA_SERIES(DADOS_CONSOLIDADOS_LEVE_tibble)
series_maxcoin=MONTA_SERIES(DADOS_CONSOLIDADOS_MAXCOIN_tibble)

#### EXTRAI DADOS DAS BARRAS SELECIONADAS NO NIVEL DE TENSAO ESCOLHIDO ####
x_pesada=grep(nivel_tensao,series_pesada$barra)
x_media=grep(nivel_tensao,series_media$barra)
x_leve=grep(nivel_tensao,series_leve$barra)
x_maxcoin=grep(nivel_tensao,series_maxcoin$barra)

series_pesada=series_pesada[x_pesada,]
series_pesada <- series_pesada %>%
  filter(if_any(-barra, ~ !is.na(.) & . != 0))
series_media=series_media[x_media,]
series_media <- series_media %>%
  filter(if_any(-barra, ~ !is.na(.) & . != 0))
series_leve=series_leve[x_leve,]
series_leve <- series_leve %>%
  filter(if_any(-barra, ~ !is.na(.) & . != 0))
series_maxcoin=series_maxcoin[x_maxcoin,]
series_maxcoin <- series_maxcoin %>%
  filter(if_any(-barra, ~ !is.na(.) & . != 0))

#### MODELAGEM DAS SERIES DAS BARRAS SELECIONADAS ####
print("iniciando modelagem de previsao das cargas nas barras")
nomes_barras=data.frame(series_maxcoin$barra)
names(nomes_barras)="barras"
numero_de_barras=length(lista_barras)
perfis_sazonais<-function(dados_merge,tipo){
       # calcula fatores de proporcionalidade historicos
       if (tipo==3 | tipo==4){
           medias_mensais <- dados_merge %>%
             mutate(mes = factor(
             month(index),
             levels = 1:12,
             labels = c("Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez")
           )) %>%
           group_by(mes) %>%
           summarise(
             across(c(value, sistema_MW, barra, prop),
                    ~ mean(ifelse(.x == 0, NA, .x), na.rm = TRUE),.names = "{.col}"
             )
           )
       } else {
         medias_mensais <- dados_merge %>%
           mutate(mes = factor(
             month(index),
             levels = 1:12,
             labels = c("Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez")
           )) %>%
           group_by(mes) %>%
           summarise(
             across(c(sistema_MW, barra, prop),
                    ~ mean(ifelse(.x == 0, NA, .x), na.rm = TRUE),.names = "{.col}"
             )
           )
       }
       sazonal = medias_mensais %>%
         ungroup() %>%
         arrange(index) %>%
         select(index, prop) %>%
         slice_tail(n = 12)
       return(sazonal)  
}
if (tipo==3 | tipo==4)  pib_mensal_hist=pib_mensal
if (tipo==1 | tipo==2 | tipo==5)  {
    pib_mensal=0
    pib_mensal_hist=0
    pib_mensal_prev=0
}

previsor<-function(serie_sistema,serie_barra,pib_mensal_hist=0,pib_mensal_prev=0,previsao_demanda_sistema,horizonte,ano_mes_fim,tipo){
        # prepara serie barra
        barra_tsibble <- serie_barra |>
              pivot_longer(cols = everything(),names_to = "index",values_to = "barra") |>
              mutate(index = yearmonth(index)) |> as_tsibble(index = index)
        barra_tsibble <- barra_tsibble %>%
              mutate(across(everything(), ~ replace_na(., 0)))
        
        # prepara serie sistema
        sistema=as_tsibble(serie_sistema)
        sistema <- sistema |> dplyr::rename(sistema_MW = value)
        sistema <- sistema %>% mutate(across(everything(), ~ replace_na(., 0)))
        
        # organiza dados de barra e sistema
        dados_barra_sistema <- dplyr::inner_join(sistema,barra_tsibble,by = "index")
        if (tipo!=5) dados_barra_sistema=dados_barra_sistema%>%mutate(prop=barra/sistema_MW)
        if (tipo==5) dados_barra_sistema=dados_barra_sistema%>%mutate(prop=barra)
        dados_fit <- dados_barra_sistema |>filter(!is.na(sistema_MW))
        dados_fit <- dados_fit |>filter(!is.na(prop))
        
        # ajusta modelos de previsao da demanda do sistema
        ultimo_zero <- which(dados_fit$sistema_MW == 0)
        if (length(ultimo_zero) > 0) {
          ultimo_zero <- max(ultimo_zero)
        } else {
          ultimo_zero <- 0
        }
        if (tipo==3 | tipo==4){
            # previsao da demanda maxima do sistema com base no PIB
            pib_mensal1=as_tsibble(pib_mensal_hist)
            dados_merge <- pib_mensal1 %>%
                 inner_join(dados_fit, by = "index")
            # modelagem da serie do sistema
            # o ajuste do modelo pode mudar por conta do join com os dados da barra
            # as barras podem ter series historicas diferentes
            fit_sistema <- dados_merge %>% slice((ultimo_zero + 1):n()) |> model(
                        ARIMA(log(sistema_MW) ~ log(value)))
        }else{
            # embora tipos 1, 2 e 5 entrem aqui, esta previsao so vai valer para modelo tipo 5
            # mas o objetio fit_sitema tem as datas do horizonte de previsao
            dados_merge <-dados_fit
            fit_sistema <- dados_merge %>% slice((ultimo_zero + 1):n()) |> model(
              ETS = ETS(log(sistema_MW) ~ error("A") + trend("A") + season("A")))
#              SARIMA = ARIMA(log(sistema_MW)))
#            melhor_modelo <- glance(fit_sistema) %>%
#              slice_min(AICc, n = 1) %>%
#              pull(.model)
#            fit_sistema <- fit_sistema %>%
#              select(all_of(melhor_modelo))
        }
        
        ultimo_zero <- which(dados_fit$prop == 0)
        if (length(ultimo_zero) > 0) {
          ultimo_zero <- max(ultimo_zero)
        } else {
          ultimo_zero <- 0
        }
        
        # modelagem do fator de participacao da barra
        nobsprop=length(which(dados_merge$prop>0))
        if (nobsprop<36 | tipo==1 | tipo==3){
            # serie curta pega media mensal
            if (nobsprop<36) print("     serie curta com menos de 36 observacoes, media do fator de participacao")
            print("     previsao do fator de participacao dada pela media historica")
            sazonal=perfis_sazonais(dados_merge,tipo)
            previsao_prop=sazonal$prop
        }else{
            # modela a serie temporal do fator de participacao
            print("     previsao do fator de participacao por modelo ETS")
            if (length(ultimo_zero)>0){
                fit_prop <- dados_merge %>% slice((ultimo_zero + 1):n()) |> model(
                            ETS = ETS(prop ~ error("A") + trend("A") + season("A")))
                #            SARIMA = ARIMA(prop))
                #melhor_modelo <- glance(fit_prop) %>%
                #                 slice_min(AICc, n = 1) %>%
                #                 pull(.model)
                #fit_prop <- fit_prop %>% select(all_of(melhor_modelo))
            }else{
                fit_prop <- dados_merge %>% slice(1:n()) |> model(
                             ETS = ETS(prop ~ error("A") + trend("A") + season("A")))
                #             SARIMA = ARIMA(prop))
                #melhor_modelo <- glance(fit_prop) %>%
                #  slice_min(AICc, n = 1) %>%
                #  pull(.model)
                #fit_prop <- fit_prop %>% select(all_of(melhor_modelo))
            }
        }
        
        # compara datas
        primeiro_mes_horizonte=max(dados_merge$index)+1
        if (tipo==3 | tipo==4){
            fim <- end(pib_mensal_hist)
            if (fim[2] == 12) {
               proximo <- c(fim[1] + 1, 1)
            } else {
               proximo <- c(fim[1], fim[2] + 1)
            }
            primeiro_mes_previsao_pib=proximo
            data_pib <- yearmonth(
                sprintf("%d-%02d",primeiro_mes_previsao_pib[1],primeiro_mes_previsao_pib[2])
            )
            if (primeiro_mes_horizonte == data_pib) {
               # serie de demanda maxima termina junto do pib
               pib_previsao_tsibble <- as_tsibble(ts(as.numeric(pib_mensal_prev),start=proximo,frequency=12))
            }  else {
               # serie de demanda maxima termina antes do pib
               pib_mensal_total <- ts(
                   c(pib_mensal_hist, pib_mensal_prev),
                   start = start(pib_mensal_hist),
                   frequency = frequency(pib_mensal_hist)
               )
               pib_previsao_tsibble <- as_tsibble(pib_mensal_total) 
               pib_previsao_tsibble <- pib_previsao_tsibble |>
               filter(index >= max(dados_merge$index)+1)
            }
        }
        
        # previsao sistema pelo PIB tipo 3 e 4
        if (tipo==3 | tipo==4){
           new_data <- pib_previsao_tsibble %>%
                       filter(index <= (yearmonth(paste(ano_mes_fim[1], month.abb[ano_mes_fim[2]]))+horizonte))
           fc_sistema <- fit_sistema %>% forecast(new_data = new_data)
           previsao_sistema=fc_sistema$.mean
        }
        if (tipo==1 | tipo==2) {
           # previsao da demanda maxima do sistema pelo fator de carga  
           fc_sistema <- fit_sistema %>% forecast(h=horizonte)
           previsao_sistema=previsao_demanda_sistema
        }
        if (tipo==5) {
           fc_sistema <- fit_sistema %>% forecast(h=horizonte)
           previsao_sistema=fc_sistema$.mean
        }
        # previsao proporcao
        if (nobsprop>=36 & (tipo!=1 & tipo!=3)){
            fc_prop <- fit_prop |> forecast(h = horizonte)
            previsao_prop=fc_prop$.mean
        }
        # previsao barra
        if (tipo!=5) {
           print("     previsao da barra = produto previsao da demanda maxima x fator de participacao")
           previsao_barra=previsao_sistema*previsao_prop
        }
        if (tipo==5) {
           print("     calculo da previsao da barra por ETS")
           previsao_barra=previsao_prop
        }
        ano_start=as.numeric(substr(fc_sistema$index[1],1,4))
        mes_start=as.numeric(match(substr(fc_sistema$index[1],6,8),c("jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez")))
        previsao_barra_ts=ts(previsao_barra,start=c(ano_start,mes_start),freq=12)
        previsao_barra=as_tsibble(previsao_barra_ts)
        previsao_sistema_ts=ts(previsao_sistema,start=c(ano_start,mes_start),freq=12)
        previsao_sistema=as_tsibble(previsao_sistema_ts)

        return(list(previsao_barra=previsao_barra,previsao_barra_ts=previsao_barra_ts,previsao_sistema=previsao_sistema))
}

serie_sistema=sistema_MW
serie_sistema=suppressWarnings(window(serie_sistema,start=ano_mes_inic,end=ano_mes_fim))
if (variavel_prevista=="pesada") series_X=series_pesada
if (variavel_prevista=="media") series_X=series_media
if (variavel_prevista=="leve") series_X=series_leve
if (variavel_prevista=="coincidente") series_X=series_maxcoin
# loop de barras para o nivel de tensao selecionado
matriz_previsoes_barras=c()

for (v in 1:numero_de_barras){
     numbarra=which(series_X$barra==lista_barras[v])
     nome_barra=series_X[numbarra,1]
     ultimo_valor=which(as.numeric(series_X[numbarra,2:dim(series_X)[2]])>0)
     num_NA=length(which(is.na(series_X[numbarra,2:dim(series_X)[2]])))
     if (num_NA==0){
        # se nao tem NA
        print(paste("fazendo previsao para a barra (serie sem NA)",nomes_barras[v,1]))
        serie_barra=series_X[numbarra,2:dim(series_X)[2]]
        saida_previsor=previsor(serie_sistema,serie_barra,pib_mensal,pib_mensal_prev,previsao_demanda_sistema,horizonte,ano_mes_fim,tipo)
        previsao_serie_ts=saida_previsor$previsao_barra_ts
     }else{
        # se tem NA ou zero
        print(paste("fazendo previsao para a barra (serie com NA)",nomes_barras[v,1]))
        xvalor=as.numeric(series_X[numbarra,2:dim(series_X)[2]])[ultimo_valor]
        xposic=ultimo_valor+1
        serie_temporal = series_X[numbarra,xposic]
        saida_previsor=previsor(serie_sistema,serie_temporal,pib_mensal,pib_mensal_prev,previsao_demanda_sistema,horizonte,ano_mes_fim,tipo)
        previsao_serie_ts=saida_previsor$previsao_barra_ts
     }
     if (v==1){
         matriz_previsoes_barras=inner_join(saida_previsor$previsao_sistema,saida_previsor$previsao_barra,by="index")
     } else {
         matriz_previsoes_barras=inner_join(matriz_previsoes_barras,saida_previsor$previsao_barra,by="index")
     }
}
colnames(matriz_previsoes_barras)[-1]=c("sistema",lista_barras)
print("EXECUCAO CONCLUIDA COM SUCESSO")
return(list(matriz_previsoes_barras=matriz_previsoes_barras,serie_sistema=sistema_MW,series_barras=series_X))
}
#### FIM ####

avalia_previsao_barra<-function(dados_brutos,previsoes,busbar,variavel_prevista,tipo,grafico=FALSE){
  # CALCULA METRICAS DE DESEMPENHO DAS PREVISOES POR BARRA
  observado <- dados_brutos %>%
    pivot_longer(
      cols = -barra,
      names_to = "index",
      values_to = "observado"
    ) %>%
    mutate(index = yearmonth(index))
  observado=observado%>%filter(barra==busbar)
  
  previsao <- previsoes %>%
    select(index,all_of(busbar)) %>%
    pivot_longer(
      cols = -index,
      names_to = "barra",
      values_to = "previsao"
    )
  
  comparacao <- previsao %>%
    left_join(
      observado,
      by = c("index", "barra")
    )
  
  comparacao <- comparacao %>%
    mutate(
      erro_abs = abs(previsao - observado),
      erro_abs_perc = 100 * abs(previsao - observado) / abs(observado)
    )
  
  comparacao_limpa <- comparacao %>%
    filter(
      is.finite(previsao),
      is.finite(observado),
      is.finite(erro_abs),
      is.finite(erro_abs_perc)
    )
  
  metricas <- comparacao_limpa %>%
    as_tibble() %>%
    summarise(
      MAE  = mean(erro_abs[is.finite(erro_abs)], na.rm = TRUE),
      MAPE = mean(erro_abs_perc[is.finite(erro_abs_perc)], na.rm = TRUE)
    )
  conta_NA=length(which(is.na(metricas)))
  
  if (grafico==TRUE & conta_NA==0){
    saida_grafico=comparacao_limpa %>%
      filter(barra == busbar) %>%
      ggplot(aes(x = index)) +
      geom_line(aes(y = observado, linetype = "Observado"),linewidth = 1) +
      geom_line(aes(y = previsao, linetype = "Previsão"),linewidth = 1) +
      geom_point(aes(y = observado), size = 2) +
      geom_point(aes(y = previsao), size = 2) +
      scale_linetype_manual(values = c("Observado" = "solid", "Previsão" = "dashed")) +
      labs(
        x = NULL,
        y = "MW",
        linetype = NULL,
        title = "Comparação entre valores observados e previstos",
        subtitle = paste("barra",busbar,"-",variavel_prevista,"modelo",tipo)
      ) +
      theme_minimal()
    windows()
    plot(saida_grafico)
  }  
  return(metricas)
}

avalia_previsao_sistema<-function(previsoes,sistema_MW,tipo,grafico=FALSE){
  # CALCULA METRICAS DE DESEMPENHO DA PREVISAO DA DEMANDA MAXIMA DO SISTEMA
  barra <- "sistema"
  observado <- as_tsibble(sistema_MW)
  
  previsao <- previsoes %>%
    select(index, all_of(barra)) %>%
    rename(previsao = all_of(barra))
  
  comparacao <- previsao %>%
    left_join(observado, by = "index") %>%
    mutate(
      erro_abs = abs(previsao - value),
      erro_abs_perc = 100 * abs(previsao - value) / abs(value)
    )
  comparacao_limpa <- comparacao %>%
    filter(if_all(where(is.numeric), is.finite))
  
  metricas <- comparacao_limpa %>%
    as_tibble() %>%
    summarise(
      MAE  = mean(erro_abs[is.finite(erro_abs)], na.rm = TRUE),
      MAPE = mean(erro_abs_perc[is.finite(erro_abs_perc)], na.rm = TRUE)
    )
  conta_NA=length(which(is.na(metricas)))
  
  if (grafico==TRUE & conta_NA==0){
    saida_grafico=ggplot(comparacao_limpa, aes(x = index)) +
      geom_line(
        aes(y = value, linetype = "Observado"),
        linewidth = 1
      ) +
      geom_line(
        aes(y = previsao, linetype = "Previsão"),
        linewidth = 1
      ) +
      geom_point(aes(y = value), size = 2) +
      geom_point(aes(y = previsao), size = 2) +
      scale_linetype_manual(
        values = c(
          "Observado" = "solid",
          "Previsão" = "dashed"
        )
      ) +
      labs(
        title = "Comparação entre valores observados e previstos",
        subtitle = paste("Sistema - modelo",tipo),
        x = NULL,
        y = "MW",
        linetype = NULL
      ) +
      theme_minimal()
    windows()
    plot(saida_grafico)
  }
  
  return(metricas)
}


